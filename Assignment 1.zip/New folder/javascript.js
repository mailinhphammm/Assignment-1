var userString= prompt("Please enter choice 1, 2, 3 or exit");
var userInput = parseInt(userInput);

function robotLanguage() {
    if (case1String.count > 5){
        alert(case1String + '-bork')
    } else {case1string.count < 5){
		alert(case1String + '-boink')
		
}
do {

        switch(userString) {

            case "1":
            var case1String = prompt("enter your name");
                if (case1String === null){
                    alert("You need to enter something.");
                }
            robotLanguage(case1String);
            break;

            case "2":
			var case2String = prompt("name converted");
                if (case2String === null){
                    alert("You need to first enter a String.");
                }
			robotLanguage(case2String);
            break;

            case "3": 
			var case3String = prompt("name converted");
                if (case3String === null){
                    alert( You need to first convert your String.");
                }
            break;
            

            default:
            alert("your answer wasnt valid");
            break;

        }
      
        var userString= prompt("Please enter choice 1, 2, 3 or exit");
}

while (userString != "exit");
	alert("Thanks for using the Robot Language Converter!");